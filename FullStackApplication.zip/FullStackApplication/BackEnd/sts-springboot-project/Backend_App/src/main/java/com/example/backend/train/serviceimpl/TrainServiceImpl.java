package com.example.backend.train.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.train.entity.Train;
import com.example.backend.train.repository.TrainRepository;
import com.example.backend.train.service.TrainService;

@Service
public class TrainServiceImpl implements TrainService{
	
	@Autowired
	private TrainRepository trainRepo;

	@Override
	public Train createTrain(Train train) {
		return trainRepo.save(train);
	}

	@Override
	public List<Train> getAllTrains() {
		return trainRepo.findAll();
	}

	@Override
	public Train getSingleTrain(long id) {
		return trainRepo.findById(id).get();
	}

	@Override
	public Train updateTrain(Train train) {
		return trainRepo.save(train);
	}

	@Override
	public void deletetrain(long id) {
		trainRepo.deleteById(id);
	}

}
