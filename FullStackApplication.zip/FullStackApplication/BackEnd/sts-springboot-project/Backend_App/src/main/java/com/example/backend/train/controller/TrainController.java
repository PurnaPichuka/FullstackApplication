package com.example.backend.train.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.train.entity.Train;
import com.example.backend.train.service.TrainService;

@CrossOrigin("http://localhost:3000/")
@RestController
@RequestMapping("/trainDetails")
public class TrainController {
	
	@Autowired
	private TrainService trainService;
	
	//CREATE
	@PostMapping
	public ResponseEntity<Train> createTrain(@RequestBody Train train){
		Train addTrain = trainService.createTrain(train);
		return new ResponseEntity<Train>(addTrain,HttpStatus.CREATED);
	}
	
	//READ ALL
	@GetMapping
	public ResponseEntity<List<Train>> getAllTrains(){
		List<Train>  allTrains = trainService.getAllTrains();
		return new ResponseEntity<List<Train>>(allTrains, HttpStatus.OK);
	}
	
	//READ BY ID
	@GetMapping("/{id}")
	public ResponseEntity<Train> getSingleTrain(@PathVariable("id") long id){
		Train singleTrain = trainService.getSingleTrain(id);
		return new ResponseEntity<Train>(singleTrain, HttpStatus.OK);
	}
	
	//UPDATE
	@PutMapping("/{id}")
	public ResponseEntity<Train> updateTrain(@PathVariable("id") long id, @RequestBody Train train){
		train.setId(id);
		Train editTrain = trainService.updateTrain(train);
		return new ResponseEntity<Train>(editTrain, HttpStatus.CREATED);
	}
	
	//DELETE
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletetrain(@PathVariable("id") long id){
		trainService.deletetrain(id);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

}
