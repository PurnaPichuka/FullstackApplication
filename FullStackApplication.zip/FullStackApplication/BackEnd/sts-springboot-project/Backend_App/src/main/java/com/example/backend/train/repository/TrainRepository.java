package com.example.backend.train.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.train.entity.Train;

public interface TrainRepository extends JpaRepository<Train, Long>{

}
