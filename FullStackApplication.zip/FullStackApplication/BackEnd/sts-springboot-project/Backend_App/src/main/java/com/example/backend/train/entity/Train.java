package com.example.backend.train.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="trainDetails")
public class Train {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String trainName;
	private int trainNo;
	private int platformNo;
	
	public Train() {
		super();
	}

	public Train(long id, String trainName, int trainNo, int platformNo) {
		super();
		this.id = id;
		this.trainName = trainName;
		this.trainNo = trainNo;
		this.platformNo = platformNo;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public int getTrainNo() {
		return trainNo;
	}

	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}

	public int getPlatformNo() {
		return platformNo;
	}

	public void setPlatformNo(int platformNo) {
		this.platformNo = platformNo;
	}
	
}
