package com.example.backend.train.service;

import java.util.List;

import com.example.backend.train.entity.Train;

public interface TrainService {

	Train createTrain(Train train);

	List<Train> getAllTrains();

	Train getSingleTrain(long id);

	Train updateTrain(Train train);

	void deletetrain(long id);


}
