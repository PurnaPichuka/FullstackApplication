import React,{useState, useEffect} from 'react';
import { useParams, Link } from 'react-router-dom';
import TrainService from '../service/TrainService';


const ViewTrain = () => {

    const [trainName, setTrainName] = useState('');
    const [trainNo, setTrainNo] = useState('');
    const [platformNo, setplatformNo] = useState('');
    const {id} = useParams();

    useEffect(()=>{
        loadTrainDetails();
    },[])

    const loadTrainDetails = ()=>{
        TrainService.getTrainById(id).then((response) =>{
            setTrainName(response.data.trainName)
            setTrainNo(response.data.trainNo)
            setplatformNo(response.data.platformNo)
        }).catch(error => {
            console.log("error is"+error)
        })
    }

    return (
        <div>
            <h1>View the train details</h1>
            <div className='container'>
                <ul className='list-unstyled fw-bold'>
                    <li>Train Name-- {trainName}</li>
                    <li>Train No-- {trainNo}</li>
                    <li>Platform No-- {platformNo}</li>
                </ul>
                <Link to='/trains' className='btn btn-primary'>Back</Link>
            </div>
        </div>
    )
}

export default ViewTrain
