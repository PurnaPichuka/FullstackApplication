import React, {useState, useEffect} from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import TrainService from '../service/TrainService';


const AddTrain = () => {

    const [trainName, setTrainName] = useState('');
    const [trainNo, setTrainNo] = useState('');
    const [platformNo, setplatformNo] = useState('');
    const navigate = useNavigate();
    const {id} = useParams();

    const saveOrEditTrain = (e) => {
        e.preventDefault();
        const train = {  trainName, trainNo, platformNo}

        if(id){
            TrainService.updateTrain(id, train).then((response) => {
                console.log(response)
                navigate('/trains');
            }).catch(error => {
                console.log(error)
            })

        }else{
            TrainService.createTrain(train).then((response) =>{
                // console.log("adding"+response.data)
                navigate('/trains');
            }).catch(error => {
                console.log(error)
            })
        }

    }

    useEffect(() => {
        TrainService.getTrainById(id).then((response) =>{
            setTrainName(response.data.trainName)
            setTrainNo(response.data.trainNo)
            setplatformNo(response.data.platformNo)
        }).catch(error => {
            console.log("error is"+error)
        })
    }, []);

    const title = ()=>{
        if(id){
            return <h2 className = "text-center">Update Train</h2>
        }else{
            return <h2 className = "text-center">Add Train</h2>
        }
    }

    return (
        <div>
        <div className='container'>
        <br></br>
            <div className='row'>
                
                <div className='card col-md-5 offset-md-3'>
                    {
                        title()
                    }
                <div className='card-body'>
                    <form>
                        <div className = "form-group mb-2">
                            <label className='form-label'>Train Name:</label>
                            <input 
                            className='form-control'
                            type='text'
                            id='name'
                            placeholder='enter train name' 
                            value={trainName}
                            onChange={(e)=>setTrainName(e.target.value)}
                            />
                        </div>
                        <div className='form-group mb-2'>
                            <label className='form-label'>Train No:</label>
                            <input 
                            className='form-control'
                            type='number'
                            id='trainNo'
                            placeholder='enter train number '
                            value={trainNo}
                            onChange={(e)=>setTrainNo(e.target.value)}
                            />
                        </div>
                        <div className='my-2'>
                            <label className='form-label'>Enter Platform No:</label>
                            <input 
                            className='form-control'
                            type='number'
                            id='platformNo'
                            placeholder='enter platform no'
                            value={platformNo}
                            onChange={(e)=>{setplatformNo(e.target.value)}}
                            />
                        </div>
                        <div>
                            <button onClick={(e)=>saveOrEditTrain(e)} className='btn btn-success mx-2'>Submit</button>
                            <Link to='/trains' className='btn btn-danger'>Cancel</Link>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>
</div>
    )
}

export default AddTrain
