import React, {useState, useEffect} from 'react'
import TrainService from '../service/TrainService';
import { Link } from 'react-router-dom';

const ListOfTrains = () => {

    const [train, setTrain] = useState([])

    useEffect(()=>{
        getAllTrains();
    },[])

    const getAllTrains = () => {
        TrainService.getAllTrains().then((response)=>{
            setTrain(response.data);
        })
    }

    const deleteTrain = (id) => {
        TrainService.deleteTrain(id).then((response)=>{
            getAllTrains();
        })
    }

    return (
        <div>
            <h1>List Of Trains</h1>
            <div>
                <Link to='/addTrain' className='btn btn-primary my-3'>Add Train</Link>
            </div>
            <div className='container'>
                <table className='table table-bordered table-striped border  border-dark shadow'>
                    <thead>
                        <tr>
                            <th>Sr No</th>
                            <th>Train Name</th>
                            <th>Train No</th>
                            <th>Platform No</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            train.map((item, index)=>
                                <tr key ={item.id}>
                                    <td>{index+1}</td>
                                    <td>{item.trainName}</td>
                                    <td>{item.trainNo}</td>
                                    <td>{item.platformNo}</td>
                                    <td>
                                        <Link to={`/editTrain/${item.id}`} className='btn btn-primary mx-2'>Update</Link>
                                        <Link to={`/viewTrain/${item.id}`} className='btn btn-success mx-2'>View</Link>
                                        <button onClick={()=>deleteTrain(item.id)} className='btn btn-danger mx-2'>Delete</button>
                                    </td>
                                </tr>
                                )
                        }

                    </tbody>
                </table>
            </div>
        
        </div>
    )
}

export default ListOfTrains
