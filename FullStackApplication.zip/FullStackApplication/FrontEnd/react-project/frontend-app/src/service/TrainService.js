import axios from 'axios';

const BASE_URL = "http://localhost:8080/trainDetails"

class TrainService{
    getAllTrains(){
        return axios.get(BASE_URL)
    }

    getTrainById(id){
        return axios.get(BASE_URL+'/'+id)
    }

    createTrain(train){
        return axios.post(BASE_URL, train)
    }

    updateTrain(id, train){
        return axios.put(BASE_URL+'/'+id, train)
    }

    deleteTrain(id){
        return axios.delete(BASE_URL+'/'+id)
    }

    
}

export default new TrainService()
