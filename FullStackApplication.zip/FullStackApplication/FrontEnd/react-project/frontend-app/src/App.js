import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ListOfTrains from './components/ListOfTrains';
import AddTrain from './components/AddTrain';
import ViewTrain from './components/ViewTrain';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<ListOfTrains />}></Route>
          <Route path='/trains' element={<ListOfTrains />}></Route>
          <Route path='/addTrain' element={<AddTrain />}></Route>
          <Route path='/editTrain/:id' element={<AddTrain />}></Route>
          <Route path='/viewTrain/:id' element={<ViewTrain />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
